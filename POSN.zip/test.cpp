#include <iostream>
#include <vector>
#include <climits>
using namespace std;

#define V 9

int minDistance(const vector<int>& dist, const vector<bool>& sptSet) {
    int min = INT_MAX, min_index;

    for (int v = 0; v < V; v++)
        if (!sptSet[v] && dist[v] <= min)
            min = dist[v], min_index = v;

    return min_index;
}

void printSolution(const vector<int>& dist, int n) {
    cout << "Vertex \t Distance from Source" << endl;
    for (int i = 0; i < n; i++)
        cout << i << " \t" << dist[i] << endl;
}

void dijkstra(const vector<vector<int>>& graph, int src, int n) {
    vector<int> dist(V, INT_MAX);
    vector<bool> sptSet(V, false);

    dist[src] = 0;

    for (int count = 0; count < V-1; count++) {
        int u = minDistance(dist, sptSet);
        sptSet[u] = true;

        for (int v = 0; v < V; v++)
            if (!sptSet[v] && graph[u][v] && dist[u] != INT_MAX && dist[u] + graph[u][v] < dist[v])
                dist[v] = dist[u] + graph[u][v];
    }

    printSolution(dist, n);
}

int main() {
    vector<vector<int>> graph(V, vector<int>(V, 0));

    cout << "Enter the number of edges and vertext: ";
    int edges, vertext;
    cin >> edges >> vertext;

    cout << "Enter the edges in the format 'from to weight':" << endl;
    for (int i = 0; i < edges; i++) {
        int from, to, weight;
        cin >> from >> to >> weight;
        graph[from][to] = weight;
    }

    int src;
    cout << "Enter the source vertex: ";
    cin >> src;

    dijkstra(graph, src, vertext);

    return 0;
}
