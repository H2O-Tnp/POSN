#include <cstdio>
#include <climits>
#include <algorithm>
#include <vector>
#include <queue>

using namespace std;

/*
pair<int, int> van;
van.first <- days;
van.second <- index;
*/

class Van {
public:
    int index;
    int days;

    Van(int index, int days) {
        this->index = index;
        this->days = days;
    };
};

struct VanComparator {
    bool operator()(const Van& a, const Van& b) {
        if(b.days < a.days)
            return true;
        else if(b.days > a.days)
            return false;
        else {
            if(b.index < a.index)
                return true;
            else
                return false;
        }
    };
};

int main() {
    int N, K;
    scanf("%d %d", &N, &K);
    priority_queue<Van, vector<Van>, VanComparator> pq;
    Van van(0, 0);
    for(int i = 0; i < K; ++i) {
        van.days = 1;
        van.index = i+1;
        pq.push(van);
    }

    int t;
    for(int i = 0; i < N; ++i) {
        scanf("%d", &t);

        van = pq.top();
        printf("%d\n", van.index);
        van.days += t;

        pq.pop();
        pq.push(van);
    }

    return 0;
}
