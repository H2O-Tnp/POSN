#include <cstdio>
#include <climits>
#include <vector>

using namespace std;

int data[64][64];

bool areAllSameVal(int val, int row0, int row1, int col0, int col1) {
    for(int r = row0; r <= row1; ++r) {
        for(int c = col0; c <= col1; ++c) {
            if(data[r][c] != val)
                return false;
        }
    }
    return true;
}

bool areAllZeros(int row0, int row1, int col0, int col1) {
    return areAllSameVal(0, row0, row1, col0, col1);
}

bool areAllOnes(int row0, int row1, int col0, int col1) {
    return areAllSameVal(1, row0, row1, col0, col1);
}

int scan(int row0, int row1, int col0, int col1) {
    if(areAllZeros(row0, row1, col0, col1))
        return 2;
    else if(areAllOnes(row0, row1, col0, col1))
        return 2;

    int r = (row0 + row1) / 2;
    int c = (col0 + col1) / 2;
    return scan(row0, r, col0, c) + scan( row0,r, c+1, col1) +
        scan(r+1, row1, col0, c) + scan(r+1, row1, c+1, col1) + 1;
}

int main() {
    int L;
    scanf("%d", &L);
    for(int r = 0; r < L; ++r) {
        for(int c = 0; c < L; ++c) {
            scanf("%d", &data[r][c]);
        }
    }

    printf("%d", scan(0, L-1, 0, L-1));

    return 0;
}
