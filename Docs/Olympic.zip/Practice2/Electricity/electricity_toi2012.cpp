#include <cstdio>
#include <queue>
#include <vector>
#include <utility>

using namespace std;

typedef pair<int, int> P;

class Land {
public:
    int pos;
    int totalCost;

    Land(int pos, int totalCost) {
        this->pos = pos;
        this->totalCost = totalCost;
    };
};

struct LandComparator {
    bool operator()(const Land& L0, const Land& L1) {
        return L0.totalCost > L1.totalCost;
    };
};

priority_queue<Land, vector<Land>, LandComparator> pq;

int main() {
    int N, k;
    scanf("%d%d", &N, &k);
    vector<int> cost;
    vector<int> bestTotalCost;
    cost.resize(N);
    bestTotalCost.resize(N);
    for(int i = 0; i < N; ++i) {
        scanf("%d", &cost[i]);
    }
    bestTotalCost[0] = cost[0];

    pq.push(Land(0, cost[0]));
    for(int i = 1; i < N; ++i) {
        Land L = pq.top();
        while(L.pos + k < i) { /// beyond reach, remove
            pq.pop();
            L = pq.top();
        }
        bestTotalCost[i] = L.totalCost + cost[i];
        pq.push(Land(i, bestTotalCost[i]));
    }
    printf("%d", bestTotalCost[N-1]);

    return 0;
}