#include <cstdio>

class Node {
public:
    int val;
    Node* left;
    Node* right;
    Node* parent;
    int num_left, num_right;

    Node(int val, Node* parent) {
        this->val = val;
        this->parent = parent;
        left = nullptr;
        right = nullptr;
        num_left = 0;
        num_right = 0;
    }

    Node* addLeftChild(int val) {
        num_left += 1;
        left = new Node(val, this);
        return left;
    }

    Node* addRightChild(int val) {
        num_right += 1;
        right = new Node(val, this);
        return right;
    }

    void print() {
        printf("%val = %2d, nLeft = %2d, nRight = %2d\n",
               val, num_left, num_right);
    }
};

class Tree {
public:
    int num_nodes;
    Node* root;

    void insert(int val);
    void init(int val) {
        root = new Node(val, nullptr);
        num_nodes = 1;
    };

    /// return the number of nodes that is less than val.
    int find(int val) {
        Node* current = root;
        int n = current->num_left;
        while(current->val != val) {
            //current->print();
            if(val < current->val) {
                current = current->left;
                n -= current->num_right + 1;
            } else if(val > current->val) {
                current = current->right;
                n += current->num_left + 1;
            }
        }
        return n;
    }
};

void Tree::insert(int val) {
    num_nodes += 1;
    Node* current = root;
    while(true) {
        if(val < current->val) {
            if(current->left == nullptr) {
                current->addLeftChild(val);
                return;
            } else {
                current->num_left += 1;
                current = current->left;
            }
        } else if(val > current->val) {
            if(current->right == nullptr) {
                current->addRightChild(val);
                return;
            } else {
                current->num_right += 1;
                current = current->right;
            }
        }
    }
}

int main() {
    int N;
    scanf("%d", &N);

    int q, val;
    scanf("%d%d", &q, &val);
    Tree t;
    t.init(val);
    for(int i = 1; i < N; ++i) {
        scanf("%d%d", &q, &val);
        if(q == 1) { /// insert
            t.insert(val);
        } else if(q == 2) { /// find rank
            int num = t.num_nodes;
            printf("%d\n", t.find(val) + 1);
        }
    }
    return 0;
}

/**
12
1 5
1 6
1 4
2 4
2 5
2 6
1 8
1 1
2 5
2 1
2 4
2 6

1 2 3 3 1 2 4

==================

30
1 7
1 4
1 6
1 5
1 2
2 7
2 4
1 1
1 3
2 5
2 2
1 12
2 7
1 10
2 12
1 8
1 11
1 9
1 20
2 12
1 16
1 22
1 14
1 18
1 13
1 15
2 16
2 10
2 6
2 14

5 2 5 2 7 9 12 16 10 6 14
*/

