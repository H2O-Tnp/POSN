#include <cstdio>

int A[101][41];
int T, N;

bool drive(int m, int t) {
    if(t > 0 && A[t][m] == 1)
        return false;
    else if(t == T && A[t][m] == 0) {
        printf("reach at %d\n", m);
        return true;
    }

    if(m > 1 && drive(m-1, t+1)) {
        printf("1\n");
        return true;
    } else if(drive(m, t+1)) {
        printf("3\n");
        return true;
    } else if(m < N && drive(m+1, t+1)) {
        printf("2\n");
        return true;
    }
    return false;
    //printf("Some thing must be wrong");
}

int main() {
    int m;
    scanf("%d%d%d", &N, &m, &T);
    for(int r = 1; r <= T; ++r) {
        for(int c = 1; c <= N; ++c)
            scanf("%d", &A[r][c]);
    }
    drive(m, 0);

    return 0;
}

/*
7
5
5
0 0 0 0 0 0 0
0 0 0 0 0 0 0
0 0 0 0 0 0 0
0 1 1 0 0 0 0
1 0 1 1 1 1 1
*/