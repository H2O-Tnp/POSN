#include <cstdio>

int A[101][41];
int T, N;
int result[101];

bool drive(int m, int t) {
    if(t > 0 && A[t][m] == 1)
        return false;
    else if(t == T && A[t][m] == 0) {
        return true;
    }

    if(m > 1 && drive(m-1, t+1)) {
        result[t] = 1;
        return true;
    } else if(drive(m, t+1)) {
        result[t] = 3;
        return true;
    } else if(m < N && drive(m+1, t+1)) {
        result[t] = 2;
        return true;
    }
    return false;
    //printf("Some thing must be wrong");
}

int main() {
    int m;
    scanf("%d%d%d", &N, &m, &T);
    for(int r = 1; r <= T; ++r) {
        for(int c = 1; c <= N; ++c)
            scanf("%d", &A[r][c]);
    }
    drive(m, 0);
    for(int i = 0; i < T; ++i)
        printf("%d\n", result[i]);

    return 0;
}

/*
7
5
5
0 0 0 0 0 0 0
0 0 0 0 0 0 0
0 0 0 0 0 0 0
0 1 1 0 0 0 0
1 0 1 1 1 1 1
*/