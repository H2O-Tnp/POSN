#include <bits/stdc++.h>
using namespace std;

const int N = 64;

int n;
int arr[N][N];

int rec(int x, int y, int lv) {
  int st = arr[x][y];
  bool status = true;
  for(int i = x; i < x + lv; ++i)
    for(int j = y; j < y + lv; ++j)
      if(arr[i][j] != st) status = false;
  if(status) return 2;
  int k = lv/2;
  return 1 + rec(x, y, k) + rec(x+k, y, k) + rec(x, y+k, k) + rec(x+k, y+k, k);
}

int main() {
  scanf("%d", &n);
  for(int i = 0; i < n; ++i) 
    for(int j = 0; j < n; ++j)
      scanf("%d", &arr[i][j]);
  printf("%d\n", rec(0, 0, n));
}