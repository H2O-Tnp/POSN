#include <bits/stdc++.h>
#define long long long
using namespace std;

const int N = 1e5+5;

int n, m;
vector<int> g[N];
long d[N];

void dfs(int u) {
  for(int v : g[u]) {
    d[v] += d[u];
    dfs(v);
  }
}

int main() {
  scanf("%d %d", &n, &m);
  for(int i = 2, v; i <= n; ++i) {
    scanf("%d", &v);
    g[v].emplace_back(i);
  }
  for(int i = 0, a, b; i < m; ++i) {
    scanf("%d %d", &a, &b);
    d[a] += b;
  }
  dfs(1);
  for(int i = 1; i <= n; ++i) 
    printf("%lld ", d[i]);
  printf("\n");
}