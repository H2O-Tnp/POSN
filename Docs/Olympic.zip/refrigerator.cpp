#include <cstdio>
#include <queue>
#include <vector>

using namespace std;

// If we want to directly hold integer, you need a predefined greater<int> to
//   convert max heap to min heap.
priority_queue<int, vector<int>, greater<int>> pq;

void solve() {
    int N;
    scanf("%d", &N);
    for(int i = 0; i < N; ++i) {
        int life;
        scanf("%d", &life);
        pq.push(life);
    }

    int day = 1;
    int min_span = pq.top();
    while(min_span >= day) {  /// If the min life span is sufficient
        pq.pop();
        pq.push(min_span + 1);  /// That min life span is extended by one day.
        min_span = pq.top();
        ++day;
    }
    printf("%d\n", day-1);
}

int main() {
    int T;
    scanf("%d", &T);
    while(T--) {
        solve();
    }

    return 0;
}

/*
2
2
3 2
4
4 4 4 100
*/