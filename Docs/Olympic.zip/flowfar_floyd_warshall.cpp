#include <cstdio>
#include <ctime>
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define MAX_NODE 500
bool R[MAX_NODE][MAX_NODE]; /// Reachability matrix

void initR(int N) {
    for(int r = 0; r < N; ++r)
        for(int c = 0; c < N; ++c)
            R[r][c] = false;

    for(int k = 0; k < N; ++k) {
        R[k][k] = true;
    }
}

int main() {
    clock_t start = clock();
    int N, E;
    scanf("%d%d", &N, &E);
    initR(N);

    for(int i = 0; i < E; ++i) {
        int src, dst;
        scanf("%d%d", &src, &dst);
        R[src][dst] = true;
    }

    // Build an adjacency matrix
    for(int k = 0; k < N; ++k) {    // intermediate node
        for(int src = 0; src < N; ++src) {
            for(int dst = 0; dst < N; ++dst) {
                R[src][dst] = R[src][dst] || (R[src][k] && R[k][dst]);
            }
        }
    }

    vector<int> count(N);
    int maxR = 0;
    for(int src = 0; src < N; ++src) {
        int c = 0;
        for(int dst = 0; dst < N; ++dst) {
            if(R[src][dst])
                ++c;
        }
        count.at(src) = c;
        if(c > maxR)
            maxR = c;
    }

    printf("%d\n", maxR-1); // deduct itself from the number
    for(int i = 0; i < N; ++i)
        if(count.at(i) == maxR)
            printf("%d ", i);

    clock_t finish = clock();
    //printf("time = %.3f sec\n", (double)(finish-start)/CLOCKS_PER_SEC);

    return 0;
}
